// display.action.js

export const setHTMLBackgroundColor = color => ({
    type: 'SET_HTML_BACKGROUND_COLOR',
    payload: color
})

export const setFrameBackgroundColor = color => ({
    type: 'SET_FRAME_BACKGROUND_COLOR',
    payload: color
})

// END of document
