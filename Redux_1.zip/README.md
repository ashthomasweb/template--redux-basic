# Basic Redux Architectural Template

Slice reducers organized in folder tree structure, combineReducer used to generate Root Reducer.

5 methodologies available for wiring dispatch actions into component. Commented in/out at top/bottom of App.js.

Extractable file included in release.

'Extract All' to desired folder, run 'npm install' or equivalent.

Access basic page in your local environment through 'npm start'.

Feel free to share!



